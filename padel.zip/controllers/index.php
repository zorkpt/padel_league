<?php

require BASE_PATH .  'views/index.view.php';