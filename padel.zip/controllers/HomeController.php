<?php

class HomeController {
    public static function index() {
        require_once '../views/home/home.php';
    }
}

