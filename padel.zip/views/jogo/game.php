<?php require  BASE_PATH . "/views/partials/head.php"; ?>
<?php require  BASE_PATH . "/views/partials/nav.php"; ?>
<?php $header = 'Pagina de Jogo x'; ?>
<?php require BASE_PATH . "/views/partials/banner.php"; ?>

<main>
    <div class="mx-auto max-w-7xl py-6 sm:px-6 lg:px-8">
        <p>Ver jogos</p>
    </div>
</main>

<?php require  BASE_PATH . "/views/partials/footer.php"; ?>



